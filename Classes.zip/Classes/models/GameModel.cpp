// GameModel.cpp
#include "GameModel.h"

GameModel::GameModel(int rows, int cols)
    : _rows(rows), _cols(cols), _cardGrid(rows, std::vector<std::shared_ptr<CardModel>>(cols, nullptr)) {
}

GameModel::~GameModel() {}

int GameModel::getRows() const {
    return _rows;
}

int GameModel::getCols() const {
    return _cols;
}

std::shared_ptr<CardModel> GameModel::getCardAt(int row, int col) const {
    if (row >= 0 && row < _rows && col >= 0 && col < _cols) {
        return _cardGrid[row][col];
    }
    return nullptr;
}

void GameModel::setCardAt(int row, int col, std::shared_ptr<CardModel> card) {
    if (row >= 0 && row < _rows && col >= 0 && col < _cols) {
        _cardGrid[row][col] = card;
    }
}

void GameModel::clearCards() {
    for (int row = 0; row < _rows; ++row) {
        for (int col = 0; col < _cols; ++col) {
            _cardGrid[row][col] = nullptr;
        }
    }
}

const std::vector<std::vector<std::shared_ptr<CardModel>>>& GameModel::getCardGrid() const {
    return _cardGrid;
}
