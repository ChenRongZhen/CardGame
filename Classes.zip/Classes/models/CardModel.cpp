#include "CardModel.h"

// ���캯������ʼ����������ɫ��λ�á�����
CardModel::CardModel(CardFaceType face, CardSuitType suit, const cocos2d::Vec2& position)
    : _face(face), _suit(suit), _position(position), _area(CardArea::Playfield) // Ĭ��������Ϊ Playfield
{
}

// Getter ʵ��
CardFaceType CardModel::getFace() const {
    return _face;
}

CardSuitType CardModel::getSuit() const {
    return _suit;
}

cocos2d::Vec2 CardModel::getPosition() const {
    return _position;
}

CardArea CardModel::getArea() const {
    return _area;
}

// Setter ʵ��
void CardModel::setFace(CardFaceType face) {
    _face = face;
}

void CardModel::setSuit(CardSuitType suit) {
    _suit = suit;
}

void CardModel::setPosition(const cocos2d::Vec2& pos) {
    _position = pos;
}

void CardModel::setArea(CardArea area) {
    _area = area;
}
