#include "CardView.h"
USING_NS_CC;

/// ������תΪ�ַ������� 1->"A"��11->"J"��13->"K"
std::string rankToString(int rank) {
    if (rank >= 2 && rank <= 10) return std::to_string(rank);
    switch (rank) {
    case 1: return "A";
    case 11: return "J";
    case 12: return "Q";
    case 13: return "K";
    default: return "X"; // �Ƿ����� fallback
    }
}

/// ���ݻ�ɫ��ŷ�����ɫǰ׺��"black"��"red"��
std::string suitColorPrefix(int suit) {
    return (suit == 0 || suit == 3) ? "black" : "red";
}

/// ���ݻ�ɫ��ŷ���Ӣ�����ƣ��� club��heart��
std::string suitName(int suit) {
    std::string suitNames[] = { "club", "diamond", "heart", "spade" };
    if (suit < 0 || suit >= 4) {
        CCLOG("Invalid suit index: %d", suit);
        return "unknown";
    }
    return suitNames[suit];
}

/// ����ָ����ɫ������Ŀ��ƶ���
CardView* CardView::create(CardSuitType suit, CardFaceType rank) {
    if (suit < CST_CLUBS || suit >= CST_NUM_CARD_SUIT_TYPES) {
        CCLOG("Invalid suit index: %d", static_cast<int>(suit));
        suit = CST_SPADES;
    }
    if (rank <= CFT_ACE || rank > CFT_NUM_CARD_FACE_TYPES) {
        CCLOG("Invalid rank index: %d", static_cast<int>(rank));
        rank = CFT_ACE;
    }

    CardView* card = new (std::nothrow) CardView();
    if (card && card->initWithFile("card_general.png")) {
        card->autorelease();
        card->_suit = suit;
        card->_rank = rank;
        card->updateView(suit, rank);
        return card;
    }
    CC_SAFE_DELETE(card);
    return nullptr;
}

/// ˢ�¿�����ʾ������ͼ������
void CardView::updateView(CardSuitType suit, CardFaceType rank) {
    this->removeAllChildren(); // ���������
    _suit = suit;
    _rank = rank;

    std::string rankStr = rankToString(static_cast<int>(rank));
    std::string color = suitColorPrefix(static_cast<int>(suit));
    std::string suitStr = suitName(static_cast<int>(suit));
    Size size = this->getContentSize();

    // ���Ͻ�С����
    auto smallNum = Sprite::create("number/small_" + color + "_" + rankStr + ".png");
    if (smallNum) {
        smallNum->setAnchorPoint(Vec2(0, 1));
        smallNum->setPosition(Vec2(9, size.height - 8));
        smallNum->setScale(1.2f);
        this->addChild(smallNum);
    }

    // ���Ͻ�С��ɫ
    auto smallSuit = Sprite::create("suits/" + suitStr + ".png");
    if (smallSuit) {
        smallSuit->setAnchorPoint(Vec2(1, 1));
        smallSuit->setPosition(Vec2(size.width - 1, size.height - 8));
        smallSuit->setScale(1.2f);
        this->addChild(smallSuit);
    }

    // �м������
    auto bigNum = Sprite::create("number/big_" + color + "_" + rankStr + ".png");
    if (bigNum) {
        bigNum->setAnchorPoint(Vec2(0.5, 0.5));
        bigNum->setPosition(Vec2(size.width / 2, size.height / 2 - 10));
        bigNum->setScale(0.8f);
        this->addChild(bigNum);
    }
}

/// ���ÿ����Ƿ�ɵ����true=���ã�false=����
void CardView::setTouchEnabled(bool enabled) {
    if (enabled) {
        if (!_touchListener) {
            _touchListener = EventListenerTouchOneByOne::create();
            _touchListener->setSwallowTouches(true);

            _touchListener->onTouchBegan = [this](Touch* touch, Event* event) {
                Vec2 localPos = this->convertToNodeSpace(touch->getLocation());
                Rect rect(0, 0, this->getContentSize().width, this->getContentSize().height);
                return rect.containsPoint(localPos);
                };

            _touchListener->onTouchEnded = [this](Touch* touch, Event* event) {
                if (_clickCallback) _clickCallback(this);
                };

            _eventDispatcher->addEventListenerWithSceneGraphPriority(_touchListener, this);
        }
    }
    else {
        if (_touchListener) {
            _eventDispatcher->removeEventListener(_touchListener);
            _touchListener = nullptr;
        }
    }
}

/// ���ӿ��Ƶ���¼�������
/// ���� callback�����Ʊ����ʱ�Ļص�����
void CardView::addClickEventListener(const std::function<void(CardView*)>& callback) {
    _clickCallback = callback;
}
