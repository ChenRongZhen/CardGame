
// CardDefs.h
#pragma once

enum CardSuitType {
    CST_NONE = -1,
    CST_CLUBS,      // 0
    CST_DIAMONDS,   // 1
    CST_HEARTS,     // 2
    CST_SPADES,     // 3
    CST_NUM_CARD_SUIT_TYPES
};

enum CardFaceType {
    CFT_NONE = -1,
    CFT_ACE,        // 0
    CFT_TWO,        // 1
    CFT_THREE,
    CFT_FOUR,
    CFT_FIVE,
    CFT_SIX,
    CFT_SEVEN,
    CFT_EIGHT,
    CFT_NINE,
    CFT_TEN,
    CFT_JACK,
    CFT_QUEEN,
    CFT_KING,       // 12
    CFT_NUM_CARD_FACE_TYPES
};