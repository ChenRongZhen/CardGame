// GameView.cpp

#include "GameView.h"
#include "CardView.h"
#include "CardDefs.h"
#include "json/document.h"
#include "json/filereadstream.h"
#include "json/error/en.h"
#include "platform/CCFileUtils.h"

USING_NS_CC;

// GameView��������Ϸ��������Ⱦ�뽻���ĳ�����
Scene* GameView::createScene() {
    return GameView::create();
}

// ��ʼ����Ϸ��ͼ�����������㡢�������������ͳ�����ť
bool GameView::init() {
    if (!Scene::init()) return false;

    Size visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();
    CCLOG("visibleSize: width=%f, height=%f", visibleSize.width, visibleSize.height);

    auto layerColor = LayerColor::create(Color4B::WHITE);  // ��ɫ����
    this->addChild(layerColor);

    auto mainBg = LayerColor::create(Color4B(220, 220, 220, 255)); // ��������
    mainBg->setContentSize(Size(visibleSize.width, MAIN_AREA_HEIGHT));
    mainBg->setPosition(Vec2(0, STACK_AREA_HEIGHT));
    this->addChild(mainBg, 0);

    auto stackBg = LayerColor::create(Color4B(180, 220, 250, 255)); // ����������
    stackBg->setContentSize(Size(visibleSize.width, STACK_AREA_HEIGHT));
    stackBg->setPosition(Vec2(0, 0));
    this->addChild(stackBg, 0);

    auto mainArea = Node::create();  // ����Ϸ����ڵ�
    mainArea->setContentSize(Size(SCREEN_WIDTH, MAIN_AREA_HEIGHT));
    mainArea->setPosition(Vec2(0, STACK_AREA_HEIGHT));
    this->addChild(mainArea, 1, "MainArea");

    auto stackArea = Node::create();  // �������ڵ�
    stackArea->setContentSize(Size(SCREEN_WIDTH, STACK_AREA_HEIGHT));
    stackArea->setPosition(Vec2(0, 0));
    this->addChild(stackArea, 1, "StackArea");

    // ������ť
    _undoButton = MenuItemImage::create(
        "undo_normal.png", "undo_selected.png",
        CC_CALLBACK_1(GameView::onUndoButtonClicked, this));

    if (_undoButton) {
        _undoButton->setScale(0.8f);
        _undoButton->setPosition(Vec2(
            origin.x + visibleSize.width - _undoButton->getContentSize().width / 2 - 20,
            origin.y + _undoButton->getContentSize().height / 2 + 20));
        auto menu = Menu::create(_undoButton, nullptr);
        menu->setPosition(Vec2::ZERO);
        this->addChild(menu, 100);
        CCLOG("Undo button created and added to scene.");
    }
    else {
        CCLOG("Failed to create undo button. Check if 'undo_normal.png' exists.");
    }

    createCards();  // ���ؿ������ݲ�����
    return true;
}

// ���Ƶ���¼�����
void GameView::onCardClicked(cocos2d::Ref* sender) {
    auto card = dynamic_cast<CardView*>(sender);
    if (!card) return;

    if (std::find(_stackCards.begin(), _stackCards.end(), card) != _stackCards.end()) {
        if (card != _topCard) {
            recordMove(card, card->getPosition());
            moveCardToTop(card, _topCard->getPosition());
            _topCard = card;
        }
    }
    else {
        if (_topCard && canMatchCards(card, _topCard)) {
            recordMove(card, card->getPosition());
            moveCardToTop(card, _topCard->getPosition());
            _topCard = card;
        }
    }
}

// �ж����ſ����Ƿ��������
bool GameView::canMatchCards(CardView* card1, CardView* card2) {
    if (!card1 || !card2) return false;
    int rank1 = static_cast<int>(card1->getRank());
    int rank2 = static_cast<int>(card2->getRank());
    return std::abs(rank1 - rank2) == 1;
}

// �������ƶ���ָ��λ�ò��������
void GameView::moveCardToTop(CardView* card, const cocos2d::Vec2& targetPos) {
    auto moveAction = MoveTo::create(0.3f, targetPos);
    card->runAction(moveAction);
    card->setLocalZOrder(++_currentZOrder);
}

// ��¼�����ƶ�ǰλ���Ա㳷��
void GameView::recordMove(CardView* card, const cocos2d::Vec2& originalPos) {
    _moveHistory.push_back({ card, originalPos, card->getLocalZOrder() }); // ���� zOrder
}

// ������ť����¼��ص�
void GameView::onUndoButtonClicked(cocos2d::Ref* sender) {
    undoLastMove();
}

// ������һ������
void GameView::undoLastMove() {
    if (_moveHistory.empty()) return;
    auto lastMove = _moveHistory.back();
    _moveHistory.pop_back();

    auto card = lastMove.card;
    auto originalPos = lastMove.originalPos;
    int originalZ = lastMove.originalZOrder;

    card->runAction(MoveTo::create(0.3f, originalPos));
    card->setLocalZOrder(originalZ);  // �ָ�ԭʼZ˳��

    if (card == _topCard && !_stackCards.empty()) {
        _topCard = _stackCards.back();
    }
}

// ���عؿ� JSON ����������
void GameView::createCards() {
    CCLOG("createCards() called");
    std::string filePath = FileUtils::getInstance()->fullPathForFilename("level_1.json");
    CCLOG("Full path for level_1.json: %s", filePath.c_str());

    FILE* fp = fopen(filePath.c_str(), "rb");
    if (!fp) {
        CCLOG("Failed to open level_1.json");
        return;
    }

    char readBuffer[65536];
    rapidjson::FileReadStream is(fp, readBuffer, sizeof(readBuffer));
    rapidjson::Document doc;
    doc.ParseStream(is);
    fclose(fp);

    if (doc.HasParseError()) {
        CCLOG("JSON parse error: %s", rapidjson::GetParseError_En(doc.GetParseError()));
        return;
    }

    auto mainArea = this->getChildByName("MainArea");
    auto stackArea = this->getChildByName("StackArea");

    auto addCardClickEvent = [this](CardView* card) {
        if (card) {
            card->setTouchEnabled(true);
            card->addClickEventListener(CC_CALLBACK_1(GameView::onCardClicked, this));
        }
        };

    // ������������
    if (doc.HasMember("Playfield") && doc["Playfield"].IsArray()) {
        const auto& playfield = doc["Playfield"];
        for (rapidjson::SizeType i = 0; i < playfield.Size(); ++i) {
            const auto& cardData = playfield[i];
            int face = cardData["CardFace"].GetInt() + 1;
            int suit = cardData["CardSuit"].GetInt();
            float x = cardData["Position"]["x"].GetFloat();
            float y = cardData["Position"]["y"].GetFloat();

            Vec2 offset(0, STACK_AREA_HEIGHT);
            auto card = CardView::create(static_cast<CardSuitType>(suit), static_cast<CardFaceType>(face));
            if (card) {
                card->setPosition(Vec2(x, y) + offset);
                this->addChild(card);
                addCardClickEvent(card);
                CCLOG("Created Playfield card face=%d suit=%d at position=(%.1f, %.1f)", face, suit, x + offset.x, y + offset.y);
            }
            else {
                CCLOG("Failed to create Playfield CardView for face=%d suit=%d", face, suit);
            }
        }
    }

    // ��������������
    if (doc.HasMember("Stack") && doc["Stack"].IsArray()) {
        const auto& stack = doc["Stack"];
        size_t stackSize = stack.Size();

        constexpr float STACK_VERTICAL_OFFSET = 60.0f;
        constexpr float STACK_OFFSET = 200.0f;
        constexpr float TOP_CARD_X_OFFSET = 200.0f;

        for (rapidjson::SizeType i = 0; i < stackSize; ++i) {
            const auto& cardData = stack[i];
            int face = cardData["CardFace"].GetInt() + 1;
            int suit = cardData["CardSuit"].GetInt();
            float x = cardData["Position"]["x"].GetFloat();
            float y = cardData["Position"]["y"].GetFloat();
            if (i == stackSize - 1) x += TOP_CARD_X_OFFSET;

            auto card = CardView::create(static_cast<CardSuitType>(suit), static_cast<CardFaceType>(face));
            if (card) {
                card->setPosition(Vec2(x + STACK_OFFSET, y + STACK_VERTICAL_OFFSET));
                this->addChild(card);
                card->setLocalZOrder(static_cast<int>(i));
                _stackCards.push_back(card);
                addCardClickEvent(card);

                CCLOG("Created Stack card face=%d suit=%d at position=(%.1f, %.1f) zOrder=%d",
                    face, suit, x + STACK_OFFSET, y + STACK_VERTICAL_OFFSET, card->getLocalZOrder());
            }
            else {
                CCLOG("Failed to create Stack CardView for face=%d suit=%d", face, suit);
            }
        }

        if (!_stackCards.empty()) {
            _topCard = _stackCards.back();

            if (_undoButton && _topCard) {
                float padding = 20.0f;
                auto topCardPosition = _topCard->getPosition();
                auto topCardSize = _topCard->getContentSize();
                auto undoButtonSize = _undoButton->getContentSize();

                float undoX = topCardPosition.x + topCardSize.width / 2 + undoButtonSize.width / 2 + padding;
                float undoY = topCardPosition.y;
                _undoButton->setPosition(Vec2(undoX, undoY));
                _undoButton->setLocalZOrder(static_cast<int>(stackSize) + 10);
            }
        }
    }

    CCLOG("Level loaded successfully from level_1.json");
}