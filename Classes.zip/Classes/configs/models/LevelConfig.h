#pragma once

#include "cocos2d.h"

struct CardConfigData {
    int face;
    int suit;
    cocos2d::Vec2 position;
};

struct LevelConfig {
    std::vector<CardConfigData> playfieldCards;
    std::vector<CardConfigData> stackCards;
};
