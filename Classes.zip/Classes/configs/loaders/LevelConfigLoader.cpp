#include "LevelConfigLoader.h"
#include "platform/CCFileUtils.h"
#include "json/document.h"
#include "json/filereadstream.h"
#include "json/error/en.h"

using namespace cocos2d;

bool LevelConfigLoader::loadLevelFromFile(const std::string& filename, LevelConfig& outConfig) {
    std::string fullPath = FileUtils::getInstance()->fullPathForFilename(filename);
    FILE* fp = fopen(fullPath.c_str(), "rb");
    if (!fp) return false;

    char buffer[65536];
    rapidjson::FileReadStream is(fp, buffer, sizeof(buffer));
    rapidjson::Document doc;
    doc.ParseStream(is);
    fclose(fp);

    if (doc.HasParseError()) return false;

    auto parseCards = [](const rapidjson::Value& array, std::vector<CardConfigData>& output) {
        for (rapidjson::SizeType i = 0; i < array.Size(); ++i) {
            const auto& item = array[i];
            CardConfigData data;
            data.face = item["CardFace"].GetInt() + 1;
            data.suit = item["CardSuit"].GetInt();
            data.position.x = item["Position"]["x"].GetFloat();
            data.position.y = item["Position"]["y"].GetFloat();
            output.push_back(data);
        }
        };

    if (doc.HasMember("Playfield") && doc["Playfield"].IsArray()) {
        parseCards(doc["Playfield"], outConfig.playfieldCards);
    }

    if (doc.HasMember("Stack") && doc["Stack"].IsArray()) {
        parseCards(doc["Stack"], outConfig.stackCards);
    }

    return true;
}
