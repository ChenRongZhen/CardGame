#pragma once

#include "configs/models/LevelConfig.h"
#include <string>

class LevelConfigLoader {
public:
    static bool loadLevelFromFile(const std::string& filename, LevelConfig& outConfig);
};
