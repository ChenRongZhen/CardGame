#include "services/GameModelFromLevelGenerator.h"
#include "configs/models/LevelConfig.h"
#include "models/CardModel.h"

std::shared_ptr<GameModel> GameModelFromLevelGenerator::generate(const LevelConfig& levelConfig) {
    auto gameModel = std::make_shared<GameModel>();

    // ���� Playfield ������
    for (const auto& cardData : levelConfig.playfieldCards) {
        auto cardModel = std::make_shared<CardModel>(
            static_cast<CardSuitType>(cardData.suit),
            static_cast<CardFaceType>(cardData.face)
        );
        cardModel->setPosition(cardData.position);
        cardModel->setArea(CardArea::Playfield);
        gameModel->addCard(cardModel);
    }

    // ���� Stack ������
    for (const auto& cardData : levelConfig.stackCards) {
        auto cardModel = std::make_shared<CardModel>(
            static_cast<CardSuitType>(cardData.suit),
            static_cast<CardFaceType>(cardData.face)
        );
        cardModel->setPosition(cardData.position);
        cardModel->setArea(CardArea::Stack);
        gameModel->addCard(cardModel);
    }

    return gameModel;
}
