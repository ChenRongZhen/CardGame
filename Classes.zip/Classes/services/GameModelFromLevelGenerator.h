// GameModelFromLevelGenerator.h
#ifndef __GAME_MODEL_FROM_LEVEL_GENERATOR_H__
#define __GAME_MODEL_FROM_LEVEL_GENERATOR_H__

#include <memory>
#include "configs/models/LevelConfig.h"
#include "models/GameModel.h"

class GameModelFromLevelGenerator {
public:
    // ��̬���������� GameModel
    static std::shared_ptr<GameModel> generate(const LevelConfig& levelConfig);
};

#endif // __GAME_MODEL_FROM_LEVEL_GENERATOR_H__
